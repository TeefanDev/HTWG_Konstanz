package aufgabe4;

/**
 *
 * @author Julian Klimek
 * @since 11.04.22
 */
public abstract class AbstractFrequencyTable<T extends Element<T>> implements FrequencyTable<T> {
	@Override
	public boolean isEmpty() {
		return this.size() == 0;
	}

	@Override
    public void add(T w) {
        add(w, 1);
    }

	@Override
	public void addAll(FrequencyTable<T> fq) {
		int n = fq.size();
		for(int i = 0; i < n; i++) {
			this.add(fq.get(i).getElement(), fq.get(i).getFrequency());
		}
	}

	@Override
	public void collectMostFrequent(FrequencyTable<T> fq) {
		fq.clear();
		int i = 0;
		fq.add(get(i).getElement(), get(i).getFrequency());
		while(get(i).getFrequency() == get(i+1).getFrequency()) {
			fq.add(get(i+1).getElement(), get(i+1).getFrequency());
			i++;
		}
	}

	@Override
	public void collectLeastFrequent(FrequencyTable<T> fq) {
		fq.clear();
		int i = size()-1;
		fq.add(get(i-1).getElement(), get(i-1).getFrequency());
		while(get(i).getFrequency() == get(i-1).getFrequency()) {
			fq.add(get(i).getElement(), get(i).getFrequency());
			i--;
		}
	}

	/**
	 * Liefert eine String-Darstellung zur&uuml;ck.
	 * @return String-Darstellung.
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder("");
		s.append("{");
		for (int i = 0; i < size(); i++) {
			s.append(get(i)).append(", ");
		}
		s.append("} ");
		s.append("size = ").append(size());
		return s.toString();
	}
}
