package aufgabe4;

/**
 *
 * @author Julian Klimek
 * @since 11.04.22
 */

public class RedCard extends Card {


}
