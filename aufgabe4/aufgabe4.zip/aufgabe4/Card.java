package aufgabe4;

/**
 *
 * @author Julian Klimek
 * @since 18.04.22
 */

public abstract class Card implements FrequencyTable<T> {
    private int size;
    private Card fqTable[];
    private final int DEFAULT_SIZE = 100;

    public Card(String farbe, String wert) {
        clear();
    }

    @Override
    public final void clear() {
        size = 0;
        fqTable = new Card[DEFAULT_SIZE];
    }

    @Override
    int get(Card c);

    @Override
    Card get(int pos);

    @Override public boolean equals(Object o) {
        if (o instanceof Card) {
            Card that = (Card) o;
            return this.card == that.card;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("");
        s.append("{");
        for (int i = 0; i < size(); i++) {
            s.append(get(i)).append(", ");
        }
        s.append("} ");
        s.append("size = ").append(size());
        return s.toString();
    }
}
